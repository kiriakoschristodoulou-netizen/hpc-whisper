# The HPC Whisper sound format (version 2)

Everything needed to write a sender or a receiver for any device. The reference
code is `handheld/wmodem.pas` (the sender, whole numbers only), `modem.js` (the
receiver page, and a sender for tests) and
`android/app/src/main/java/net/kyriakos/whisper/Receiver.java` (the keyboard's
receiver, a line-by-line port of `modem.js`). The tests in `tests/` check all
three against each other.

## Tones

- A grid of tones 100 Hz apart, from 18,000 to 21,500 Hz (36 tones).
- A **band** is 16 neighbouring grid tones. Bands start at 18,000, 18,500,
  19,000, 19,500 or 20,000 Hz. Tone *v* (0 to 15) of a band starting at *B*
  is *B* + 100·*v* Hz.
- One tone is one **symbol** and carries 4 bits. A symbol lasts 48, 32 or
  20 ms (Slow, Normal, Fast). Symbol *k* of a frame starts at sample
  ⌊*k* · rate · ms / 1000⌋ from the start of the frame.
- The tone is a sine wave whose phase runs on without a jump from one symbol
  to the next. The frame fades in and out over 5 ms. Between frames there
  is at least 60 ms of silence.
- The handheld plays at 44,100 samples per second; the receiver may listen at
  any rate of 44,100 or more.

## Frame

1. **Preamble**, 8 symbols: `0 15 0 15 11 4 11 4`. A receiver should accept
   it with up to two of the eight drowned out.
2. **Blocks**: a header block and *B* body blocks, each a Reed-Solomon
   (15, 11) code word over GF(16), **interleaved**: symbol *t* after the
   preamble is symbol ⌊*t* / (*B*+1)⌋ of block *t* mod (*B*+1), the header
   being block 0. A burst of noise or a dropout so touches each block only
   lightly.

The **header** block's 11 nibbles:

| Nibbles | Meaning |
| --- | --- |
| 0 | format version, 2 |
| 1–2 | *n*, the number of text bytes (0 to 44) |
| 3–4 | sequence number (one more for each frame) |
| 5–6 | document id (changes when the handheld starts a new page) |
| 7–10 | *L*, the document's length in bytes |

The **body** bytes, as nibbles (high first), padded with zeros to a multiple
of 11 and cut into *B* = ⌈(*n* + 4) · 2 / 11⌉ blocks:

| Bytes | Meaning |
| --- | --- |
| 0–1 | *o*, the offset in the document where the text starts |
| 2 … *n*+1 | the text: document bytes *o* … *o*+*n*−1 (UTF-8) |
| *n*+2, *n*+3 | CRC-16 (CCITT: polynomial 0x1021, start 0xFFFF, high byte first) of *n*, sequence, document id, *L* (2 bytes), *o* (2 bytes) and the text |

Reed-Solomon code: field polynomial *x*⁴ + *x* + 1 (0x13), α = 2, generator
(*x* − α)(*x* − α²)(*x* − α³)(*x* − α⁴), systematic (the check nibbles are the
remainder of the data · *x*⁴ divided by the generator, highest power first).
A block corrects *e* wrong symbols and *f* symbols marked as unreliable when
2*e* + *f* ≤ 4.

## Meaning: a mirror of the document

Each frame says: **the document is *L* bytes long, and from offset *o* it
reads these bytes.** The receiver keeps a copy of the document: it sets the
length to *L* (forgetting anything beyond) and writes the bytes at *o*.
Bytes it has never received are missing, not wrong. A new document id means
a new page: the previous one is finished.

The handheld sends:

- **new text at once**, starting a little earlier when there is room, so
  that text which went out once goes out a second time with it;
- in a **pause of 0.4 s**, anything that went out only once, again;
- in a **pause of 1.5 s**, everything a third time;
- in a **pause of 3 s**, the last 22 bytes once more;
- in a **rest of 5 s**, one sweep over the last 300 bytes.

So a frame lost on the way leaves a gap that fills in a moment later. Repeat
frames carry at most 22 bytes: shorter frames get through more often.

## Receiving, in brief

- Measure each grid tone in 1 ms steps (a running complex sum per tone), so
  any window's strength is a difference of two sums.
- Look for the preamble in every band and speed, all the time, even while
  frames are being read: in each of its eight windows, the expected tone
  should be the strongest of the band's 16. Use the middle of each symbol
  (from 25 % to 90 % of it), so echoes of the previous symbol do not count.
- Try the frame at each possible size *B*, smallest first, as soon as that
  much has been heard. A block that does not check out is tried again with
  its least certain symbols (the weakest share of their band's power) marked
  as unreliable, one to four of them.
- If no size works, the sender's sound may have stopped for a moment, which
  delays every later tone: at the sizes where the sound really ended, try
  each place and length of such a gap, and keep one that passes the CRC.
