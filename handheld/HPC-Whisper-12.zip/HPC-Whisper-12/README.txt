HPC Whisper 1.2
by Kyriakos Christodoulou

Type on a Windows CE handheld PC and the text goes straight into any app
on your phone, carried by tones too high to hear. No cable, no network.
Made on, and for, the HP Jornada 720.

THE PHONE
  Android: install the HPC Whisper keyboard, HPC-Whisper.apk, from
  https://github.com/kiriakoschristodoulou-netizen/hpc-whisper/releases
  Open it, follow the three setup steps, then in any app (an email in
  Gmail, a message, a note) switch to the HPC Whisper keyboard and type
  on the handheld.

  iPhone, or any other phone: Apple does not let keyboards use the
  microphone at all, so an iPhone keyboard is impossible. Use the
  receiver page in the browser instead, with Copy and Share:
  https://kiriakoschristodoulou-netizen.github.io/hpc-whisper/

  The phone finds the band and speed by itself.

THE HANDHELD
  Needs an ARM processor and Windows CE 3.0 or later (tested on the
  HP Jornada 720; it will not run on MIPS or SH3 machines such as the
  Jornada 680/690 or the NEC MobilePro 780).
  Copy this folder over and run whisper.exe. Just type. Backspace and
  Enter work too.

  New in 1.2: less lag. Frames stay short while you type, less sound is
  queued, and new installs start at Fast (Ctrl+P to change; a setting
  you saved before is kept).

  New in 1.1: lost pieces fill themselves in. New text goes out at once
  and is repeated during your pauses, so a piece lost to noise shows on
  the phone as a dot for a moment and fills in when the repeat arrives.
  The sound format changed: use the keyboard or page from the same
  release (version 1.0 of this program is not understood any more).

SETTINGS (saved in whisper.cfg next to the program)
  Band   (Ctrl+B)  18.0-19.5 / 18.5-20.0 / 19.0-20.5 / 19.5-21.0 /
                   20.0-21.5 kHz (default 20.0-21.5)
  Speed  (Ctrl+P)  Slow 48 ms, Normal 32 ms, Fast 20 ms per tone
                   (Fast: least lag; Slow: hardest to drown out)
  Volume (Ctrl+V)  10 to 100% (default 50%; at full volume the speaker
                   can distort into audible sound)
  Test   (Ctrl+T)  types a test sentence
  Clear  (Ctrl+L)  a new page: clears this screen, and the phone starts
                   a new paragraph
  Exit   (Ctrl+Q)

TIPS
  - Keep the phone within about a metre, microphone towards the handheld.
  - If the phone shows "too weak", try Slow, or a little more volume.
  - If you can hear the tones, choose a higher band or less volume.
  - If letters still go missing, use "Record 30 seconds" in the phone
    app and send the recording for diagnosis.
  - The system volume goes to full while the program runs and back when
    you exit; the Volume setting scales the tones themselves.

IF THE WEBSITE IS EVER GONE
  The receiver page is in source\web. Put those files on any web space
  that serves https and open it in Chrome or Safari. The sound format is
  described in full in source\FORMAT.md.
