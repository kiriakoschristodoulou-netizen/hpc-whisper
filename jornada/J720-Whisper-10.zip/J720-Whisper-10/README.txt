J720 Whisper 1.0
by Kyriakos Christodoulou

Type on the Jornada and the text appears on your phone, carried by tones
too high to hear. No cable, no network.

THE PHONE
  In Chrome: https://kiriakoschristodoulou-netizen.github.io/j720-whisper/
  Tap Listen and allow the microphone. Add it to the home screen: after
  the first visit it works with no internet.
  Or install the Android app, J720-Whisper.apk, from
  https://github.com/kiriakoschristodoulou-netizen/j720-whisper/releases
  The phone finds the band and speed by itself.

THE JORNADA
  Copy this folder over and run whisper.exe. Just type. Whatever you type
  goes out whenever the sound is free, so the phone follows a second or
  two behind. Backspace and Enter work too.

SETTINGS (saved in whisper.cfg next to the program)
  Band   (Ctrl+B)  18.0-19.5 / 18.5-20.0 / 19.0-20.5 / 19.5-21.0 /
                   20.0-21.5 kHz (default 20.0-21.5)
  Speed  (Ctrl+P)  Slow 48 ms, Normal 32 ms, Fast 20 ms per tone
                   (about 5, 8 and 12 characters a second)
  Volume (Ctrl+V)  10 to 100% (default 50%; at full volume the speaker
                   distorts into audible sound)
  Test   (Ctrl+T)  types a test sentence
  Clear  (Ctrl+L)  clears the Jornada's screen only
  Exit   (Ctrl+Q)

TIPS
  - Keep the phone within about a metre, microphone towards the Jornada.
  - If the phone shows "Unreadable", try Slow, or a little more volume.
  - If you can hear the tones, choose a higher band or less volume.
  - The system volume goes to full while the program runs and back when
    you exit; the Volume setting scales the tones themselves.

IF THE WEBSITE IS EVER GONE
  The receiver page is in source\web. Put those files on any web space
  that serves https (Netlify, Cloudflare Pages, GitHub Pages, your own
  site) and open it in Chrome. The sound format is described in full in
  source\FORMAT.md, so a receiver can be written for any device.
